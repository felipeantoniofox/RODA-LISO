import tkinter as tk
from tkinter import ttk
import webbrowser
import os

# --- BANCO DE DADOS (Escala 1 a 10000) ---
CPUS = {
    "Intel Core i7-950 ": 150,
    "Intel Core i3-4130 ": 150,
    "Intel Core i5-9400F ": 450,
    "AMD Ryzen 5 5600X ": 720,
    "Intel Core i9-14900K ": 980
}

GPUS = {
    "Intel HD Graphics 4000": 50,
    "NVIDIA GTX 750": 60,
    "NVIDIA GTX 750 Ti": 65,
    "NVIDIA GTX 760": 85,
    "NVIDIA GTX 770": 98,
    "NVIDIA GTX 780": 120,
    "NVIDIA GTX 780TI": 150,
    "NVIDIA GTX 950": 88,
    "NVIDIA GTX 960": 95,
    "NVIDIA GTX 970": 150,
    "NVIDIA GTX 980": 160,
    "NVIDIA GTX 980TI": 210,
    "NVIDIA GTX 1030": 55,
    "NVIDIA GTX 1050": 90,
    "NVIDIA GTX 1050 Ti": 102,
    "NVIDIA GTX 1060 3GB": 150,
    "NVIDIA GTX 1060 6GB": 160,
    "NVIDIA GTX 1070": 215,
    "NVIDIA GTX 1070Ti": 240,
    "NVIDIA GTX 1080": 247,
    "NVIDIA GTX 1080Ti": 330,
    "NVIDIA RTX 3060": 680,
    "AMD Radeon RX 7900 XT": 890,
    "NVIDIA RTX 4090": 1161,
    "NVIDIA RTX 5090": 1522
}

RAMS = ["256 MB","512 MB","1 GB","2 GB","4 GB", "8 GB", "16 GB", "32 GB", "64 GB"]

JOGOS = {
    "CS 2": {"cpu": 200, "gpu": 150, "ram": "4 GB"},
    "GTA V": {"cpu": 400, "gpu": 350, "ram": "8 GB"},
    "Red Dead Redemption 2": {"cpu": 600, "gpu": 550, "ram": "12 GB"},
    "Cyberpunk 2077": {"cpu": 800, "gpu": 850, "ram": "16 GB"},
    "MW2 2009" : {"cpu": 100, "gpu": 45, "ram": "1 GB"},
    "Black Ops 2" : {"cpu": 110, "gpu": 50, "ram": "2 GB"},
    "MW3 2011" : {"cpu": 100, "gpu": 50, "ram": "2 GB"}
}

# --- FUNÇÕES DE LÓGICA ---
def converter_ram_para_gb(ram_string):
    valor, unidade = ram_string.split()
    if unidade == "MB":
        return float(valor) / 1024.0
    return float(valor)

def verificar_compatibilidade():
    cpu_escolhida = combo_cpu.get()
    gpu_escolhida = combo_gpu.get()
    ram_escolhida = combo_ram.get()
    jogo_escolhido = combo_jogos.get()

    if not all([cpu_escolhida, gpu_escolhida, ram_escolhida, jogo_escolhido]):
        # Alerta Laranja (Erro de Input)
        frame_resultado.config(bg="#fff3cd", highlightbackground="#ffeeba")
        lbl_resultado.config(text="⚠️ Por favor, selecione todos os componentes!", bg="#fff3cd", fg="#856404")
        return

    pontos_cpu = CPUS[cpu_escolhida]
    pontos_gpu = GPUS[gpu_escolhida]
    ram_pc = converter_ram_para_gb(ram_escolhida)
    
    req_cpu = JOGOS[jogo_escolhido]["cpu"]
    req_gpu = JOGOS[jogo_escolhido]["gpu"]
    req_ram = converter_ram_para_gb(JOGOS[jogo_escolhido]["ram"])

    # Lógica de mudança de cores do painel de resultado
    if pontos_cpu >= req_cpu and pontos_gpu >= req_gpu and ram_pc >= req_ram:
        # Verde - Sucesso
        frame_resultado.config(bg="#d4edda", highlightbackground="#c3e6cb")
        lbl_resultado.config(text=f"✅ RODA LISO!\nScore de Hardware: {pontos_cpu + pontos_gpu} pts", bg="#d4edda", fg="#155724")
    elif ram_pc < req_ram:
        # Vermelho - Erro Crítico
        frame_resultado.config(bg="#f8d7da", highlightbackground="#f5c6cb")
        lbl_resultado.config(text=f"❌ MEMÓRIA INSUFICIENTE\nRequisito: {req_ram}GB | Seu PC: {ram_pc:.2f}GB", bg="#f8d7da", fg="#721c24")
    else:
        # Amarelo - Gargalo
        gargalo = "Placa de Vídeo (GPU)" if pontos_gpu < req_gpu else "Processador (CPU)"
        diff = req_gpu - pontos_gpu if gargalo == "Placa de Vídeo (GPU)" else req_cpu - pontos_cpu
        frame_resultado.config(bg="#fff3cd", highlightbackground="#ffeeba")
        lbl_resultado.config(text=f"⚠️ GARGALO DETECTADO: {gargalo}\nFaltam {diff} pontos de performance.", bg="#fff3cd", fg="#856404")

def abrir_video(url):
    webbrowser.open(url)

# --- UI SETUP ---
root = tk.Tk()
root.title("Roda Liso v2.0 - Performance Hub")
root.geometry("750x650")
root.configure(bg="#f0f2f5")

style = ttk.Style()
style.configure("TNotebook.Tab", padding=[20, 5], font=("Arial", 10, "bold"))
style.configure("TFrame", background="#f0f2f5")

nb = ttk.Notebook(root)
nb.pack(pady=10, expand=True, fill="both", padx=10)

f1 = ttk.Frame(nb)
f2 = ttk.Frame(nb)
nb.add(f1, text="Diagnóstico de Hardware")
nb.add(f2, text="Tutoriais de Otimização")

# ================= ABA 1: DIAGNÓSTICO (REDESIGN COMPLETO) =================
# Frame principal para dar cor de fundo
container_diag = tk.Frame(f1, bg="#f0f2f5")
container_diag.pack(fill="both", expand=True)

tk.Label(container_diag, text="🖥️ Diagnóstico de Performance", font=("Arial", 16, "bold"), bg="#f0f2f5", fg="#333").pack(pady=(20, 5))
tk.Label(container_diag, text="Selecione as especificações da máquina para simular o gargalo arquitetural.", font=("Arial", 10), bg="#f0f2f5", fg="#666").pack(pady=(0, 15))

# CARD 1: HARDWARE
frame_hw = tk.LabelFrame(container_diag, text=" ⚙️ Especificações do Hardware ", font=("Arial", 11, "bold"), bg="white", fg="#333", padx=20, pady=15)
frame_hw.pack(fill="x", padx=40, pady=10)

# Usando GRID para alinhar perfeitamente os rótulos e as caixas de seleção
tk.Label(frame_hw, text="🧠 Processador (CPU):", font=("Arial", 10, "bold"), bg="white", fg="#444").grid(row=0, column=0, sticky="e", pady=10, padx=5)
combo_cpu = ttk.Combobox(frame_hw, values=list(CPUS.keys()), width=45, state="readonly")
combo_cpu.grid(row=0, column=1, sticky="w", pady=10, padx=10)

tk.Label(frame_hw, text="🎮 Placa de Vídeo (GPU):", font=("Arial", 10, "bold"), bg="white", fg="#444").grid(row=1, column=0, sticky="e", pady=10, padx=5)
combo_gpu = ttk.Combobox(frame_hw, values=list(GPUS.keys()), width=45, state="readonly")
combo_gpu.grid(row=1, column=1, sticky="w", pady=10, padx=10)

tk.Label(frame_hw, text="⚡ Memória RAM:", font=("Arial", 10, "bold"), bg="white", fg="#444").grid(row=2, column=0, sticky="e", pady=10, padx=5)
combo_ram = ttk.Combobox(frame_hw, values=RAMS, width=45, state="readonly")
combo_ram.grid(row=2, column=1, sticky="w", pady=10, padx=10)

# CARD 2: SOFTWARE ALVO
frame_game = tk.LabelFrame(container_diag, text=" 🎯 Alvo do Diagnóstico ", font=("Arial", 11, "bold"), bg="white", fg="#333", padx=20, pady=15)
frame_game.pack(fill="x", padx=40, pady=5)

tk.Label(frame_game, text="Selecione o Jogo/Software:", font=("Arial", 10, "bold"), bg="white", fg="#444").grid(row=0, column=0, sticky="e", pady=5, padx=5)
combo_jogos = ttk.Combobox(frame_game, values=list(JOGOS.keys()), width=45, state="readonly")
combo_jogos.grid(row=0, column=1, sticky="w", pady=5, padx=10)

# BOTÃO DE AÇÃO
btn = tk.Button(container_diag, text="🚀 EXECUTAR MATCHMAKING", bg="#28a745", fg="white", activebackground="#218838", activeforeground="white", font=("Arial", 11, "bold"), command=verificar_compatibilidade, padx=20, pady=8, relief="flat", cursor="hand2")
btn.pack(pady=20)

# PAINEL DE RESULTADO (Começa neutro)
frame_resultado = tk.Frame(container_diag, bg="#e9ecef", bd=1, relief="solid", highlightbackground="#ccc", highlightthickness=1)
frame_resultado.pack(fill="x", padx=40, pady=(0, 20), ipady=15)

lbl_resultado = tk.Label(frame_resultado, text="Aguardando inserção de dados...", font=("Arial", 13, "bold"), bg="#e9ecef", fg="#6c757d", justify="center")
lbl_resultado.pack(expand=True)


# ================= ABA 2: TUTORIAIS (MANTIDO) =================
canvas = tk.Canvas(f2, bg="#f0f2f5", highlightthickness=0)
scrollbar = ttk.Scrollbar(f2, orient="vertical", command=canvas.yview)
scrollable_frame = ttk.Frame(canvas)

scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
canvas.create_window((0, 0), window=scrollable_frame, anchor="nw", width=700)
canvas.configure(yscrollcommand=scrollbar.set)

canvas.pack(side="left", fill="both", expand=True, padx=10, pady=10)
scrollbar.pack(side="right", fill="y")

tk.Label(scrollable_frame, text="CENTRAL DE CONHECIMENTO (ODS 4)", font=("Arial", 16, "bold"), bg="#f0f2f5", fg="#333").pack(pady=(10, 20))

btns_links = [
    ("Limpeza de Sistema e Debloat", "Guia para remover lixo do Windows.", "https://www.youtube.com/results?search_query=debloat+windows+10+11"),
    ("Undervolt e Gestão Térmica", "Aprenda a reduzir a temperatura da GPU.", "https://www.youtube.com/results?search_query=tutorial+undervolt+gpu+ptbr"),
    ("Diminuir temperatura de Ryzen", "Dicas práticas sem gastar dinheiro.", "https://www.youtube.com/watch?v=frsiS3g0-Mk"),
    ("Overclock em Placa de Video", "Aumente o desempenho com segurança.", "https://www.youtube.com/watch?v=BUMwelj3SaY"),
    ("Converter DirectX para Vulkan", "Melhore o desempenho de jogos antigos.", "https://github.com/doitsujin/DXVK"),
    ("Overclock em Intel 1° á 7° Gen", "Guia passo a passo para CPUs antigas.", "https://www.youtube.com/watch?v=nj60vV5Hu2A"),
    ("Otimização de Drivers Legacy", "Como instalar drivers antigos corretamente.", "https://www.youtube.com/results?search_query=como+instalar+drivers+antigos+corretamente")
]

imagens_ref = [] 

for idx, (titulo, descricao, url) in enumerate(btns_links):
    card = tk.Frame(scrollable_frame, bg="white", bd=1, relief="solid", highlightbackground="#ccc", highlightcolor="#ccc", highlightthickness=1)
    card.pack(fill="x", padx=10, pady=5)
    
    img_path = f"assets/icon_{idx}.png"
    if os.path.exists(img_path):
        try:
            img = tk.PhotoImage(file=img_path).subsample(2, 2)
            imagens_ref.append(img)
            lbl_img = tk.Label(card, image=img, bg="white")
            lbl_img.pack(side="left", padx=15, pady=10)
        except:
            lbl_img = tk.Label(card, text="⚙️", font=("Arial", 30), bg="white")
            lbl_img.pack(side="left", padx=15, pady=10)
    else:
        lbl_img = tk.Label(card, text="⚙️", font=("Arial", 30), bg="white")
        lbl_img.pack(side="left", padx=15, pady=10)

    text_frame = tk.Frame(card, bg="white")
    text_frame.pack(side="left", fill="x", expand=True, padx=10, pady=10)
    
    lbl_titulo = tk.Label(text_frame, text=titulo, font=("Arial", 12, "bold"), bg="white", fg="#222", anchor="w")
    lbl_titulo.pack(fill="x")
    
    lbl_desc = tk.Label(text_frame, text=descricao, font=("Arial", 9), bg="white", fg="#666", anchor="w")
    lbl_desc.pack(fill="x")

    btn_video = tk.Button(card, text="▶ Ver Vídeo", bg="#ff0000", fg="white", font=("Arial", 10, "bold"),
                          command=lambda u=url: abrir_video(u), relief="flat", cursor="hand2", padx=10, pady=5)
    btn_video.pack(side="right", padx=20)

root.mainloop()